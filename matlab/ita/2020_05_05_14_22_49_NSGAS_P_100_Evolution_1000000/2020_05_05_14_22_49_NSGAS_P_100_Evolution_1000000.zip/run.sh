octave --persist run.m
