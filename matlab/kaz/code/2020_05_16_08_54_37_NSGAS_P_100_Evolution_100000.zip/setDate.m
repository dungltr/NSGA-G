function [startDate stopDate] = setDate()
startDate = 8
stopDate = 44
end